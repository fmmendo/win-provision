ThrottleStop 8.70.6
TechPowerUp Edition
September 19, 2018

New Features
- improved WinRing0 security and memory access by Sam Haskins.
- ability to disable and lock the memory mapped turbo power limits.
- added IccMax adjustment.
- fixed FIVR voltage names for Skylake and newer CPUs.
- regular system tray CPU temperature updates in Stop Data mode.
- single click system tray icons and new Logo Min option.
- smaller Turbo Power Limits window.
- TS 8.70.3 - fixed Task Scheduler finding RwDrv.sys bug.
- TS 8.70.4 - fixed purple button outline in Limit Reasons.
- TS 8.70.5 - fixed Disable Turbo applied after resuming.
- TS 8.70.6 - fixed Core i5/i7 4xx0HQ Crystal Well support.
- Add logo.png (230x90) to ThrottleStop folder for custom logo.

Kevin Glynn
throttlestop@shaw.ca
